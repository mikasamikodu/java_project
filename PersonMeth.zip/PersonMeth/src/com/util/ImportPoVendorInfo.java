package com.util;

import org.apache.log4j.Logger;

public class ImportPoVendorInfo {
	public static Logger log=Logger.getLogger(ImportPoVendorInfo.class);
}
