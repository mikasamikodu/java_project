package com.util;

import org.apache.log4j.Logger;

public class ImportPersonInfo {
	public static Logger log=Logger.getLogger(ImportPersonInfo.class);
}
