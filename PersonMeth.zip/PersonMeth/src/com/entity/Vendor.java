package com.entity;

public class Vendor {
	private String vendor_id;//��Ӧ��id
	private String vendor_name;//��Ӧ������
	private String vendor_site_id;//��Ӧ�̵�ַid
	private String vendor_site_name;//��Ӧ�̵�ַ
	private String org_id;//��Ӧ��������˾id
	private String org_name;//��Ӧ��������˾
	private String arrt1;
	private String arrt2;
	private String arrt3;
	private String arrt4;
	private String arrt5;
	private String arrt6;
	
	
	public String getVendor_id() {
		return vendor_id;
	}
	public void setVendor_id(String vendor_id) {
		this.vendor_id = vendor_id;
	}
	public String getVendor_name() {
		return vendor_name;
	}
	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}
	public String getVendor_site_id() {
		return vendor_site_id;
	}
	public void setVendor_site_id(String vendor_site_id) {
		this.vendor_site_id = vendor_site_id;
	}
	public String getVendor_site_name() {
		return vendor_site_name;
	}
	public void setVendor_site_name(String vendor_site_name) {
		this.vendor_site_name = vendor_site_name;
	}
	
	public String getOrg_id() {
		return org_id;
	}
	public void setOrg_id(String org_id) {
		this.org_id = org_id;
	}
	public String getOrg_name() {
		return org_name;
	}
	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}
	public String getArrt1() {
		return arrt1;
	}
	public void setArrt1(String arrt1) {
		this.arrt1 = arrt1;
	}
	public String getArrt2() {
		return arrt2;
	}
	public void setArrt2(String arrt2) {
		this.arrt2 = arrt2;
	}
	public String getArrt3() {
		return arrt3;
	}
	public void setArrt3(String arrt3) {
		this.arrt3 = arrt3;
	}
	public String getArrt4() {
		return arrt4;
	}
	public void setArrt4(String arrt4) {
		this.arrt4 = arrt4;
	}
	public String getArrt5() {
		return arrt5;
	}
	public void setArrt5(String arrt5) {
		this.arrt5 = arrt5;
	}
	public String getArrt6() {
		return arrt6;
	}
	public void setArrt6(String arrt6) {
		this.arrt6 = arrt6;
	}
	
}
