package com.entity;

public class Sa_Opperson_Oporg {
	private String sid;
	private String sname;
	private String scode;
	private String sfname;
	private String sfid;
	private String departmentname;
	private String departmentid;
	private String sorgkindid;
	private String sparent;
	private String sidcode;
	private String svalidstate;
	private String ssex;
	private String sbirthday;
	private String sjoindate;
	private String smobilephone;
	private String sofficephone;
	private String companyid;
	private String companyname;
	private String superiorDepartmentID;
	private String superiorDepartment;
	private String currentTime;
	private String zsjState;
	private String ssequence;
	private String sparentid;
	private String snumb;
	private String arrt1;
	private String arrt2;
	private String arrt3;
	private String arrt4;
	private String arrt5;
	private String arrt6;
	private String personMechId;
	
	
	
	public String getPersonMechId() {
		return personMechId;
	}
	public void setPersonMechId(String personMechId) {
		this.personMechId = personMechId;
	}
	public String getArrt1() {
		return arrt1;
	}
	public void setArrt1(String arrt1) {
		this.arrt1 = arrt1;
	}
	public String getArrt2() {
		return arrt2;
	}
	public void setArrt2(String arrt2) {
		this.arrt2 = arrt2;
	}
	public String getArrt3() {
		return arrt3;
	}
	public void setArrt3(String arrt3) {
		this.arrt3 = arrt3;
	}
	public String getArrt4() {
		return arrt4;
	}
	public void setArrt4(String arrt4) {
		this.arrt4 = arrt4;
	}
	public String getArrt5() {
		return arrt5;
	}
	public void setArrt5(String arrt5) {
		this.arrt5 = arrt5;
	}
	public String getArrt6() {
		return arrt6;
	}
	public void setArrt6(String arrt6) {
		this.arrt6 = arrt6;
	}
	public String getSnumb() {
		return snumb;
	}
	public void setSnumb(String snumb) {
		this.snumb = snumb;
	}
	public String getCurrentTime() {
		return currentTime;
	}
	public void setCurrentTime(String currentTime) {
		this.currentTime = currentTime;
	}
	public String getZsjState() {
		return zsjState;
	}
	public void setZsjState(String zsjState) {
		this.zsjState = zsjState;
	}
	public String getSsequence() {
		return ssequence;
	}
	public void setSsequence(String ssequence) {
		this.ssequence = ssequence;
	}
	public String getSparentid() {
		return sparentid;
	}
	public void setSparentid(String sparentid) {
		this.sparentid = sparentid;
	}
	public String getSuperiorDepartmentID() {
		return superiorDepartmentID;
	}
	public void setSuperiorDepartmentID(String superiorDepartmentID) {
		this.superiorDepartmentID = superiorDepartmentID;
	}
	public String getSuperiorDepartment() {
		return superiorDepartment;
	}
	public void setSuperiorDepartment(String superiorDepartment) {
		this.superiorDepartment = superiorDepartment;
	}
	public String getCompanyid() {
		return companyid;
	}
	public void setCompanyid(String companyid) {
		this.companyid = companyid;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getScode() {
		return scode;
	}
	public void setScode(String scode) {
		this.scode = scode;
	}
	public String getSfname() {
		return sfname;
	}
	public void setSfname(String sfname) {
		this.sfname = sfname;
	}
	public String getSfid() {
		return sfid;
	}
	public void setSfid(String sfid) {
		this.sfid = sfid;
	}
	public String getDepartmentname() {
		return departmentname;
	}
	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}
	public String getDepartmentid() {
		return departmentid;
	}
	public void setDepartmentid(String departmentid) {
		this.departmentid = departmentid;
	}
	public String getSorgkindid() {
		return sorgkindid;
	}
	public void setSorgkindid(String sorgkindid) {
		this.sorgkindid = sorgkindid;
	}
	public String getSparent() {
		return sparent;
	}
	public void setSparent(String sparent) {
		this.sparent = sparent;
	}
	public String getSidcode() {
		return sidcode;
	}
	public void setSidcode(String sidcode) {
		this.sidcode = sidcode;
	}
	public String getSvalidstate() {
		return svalidstate;
	}
	public void setSvalidstate(String svalidstate) {
		this.svalidstate = svalidstate;
	}
	public String getSsex() {
		return ssex;
	}
	public void setSsex(String ssex) {
		this.ssex = ssex;
	}
	public String getSbirthday() {
		return sbirthday;
	}
	public void setSbirthday(String sbirthday) {
		this.sbirthday = sbirthday;
	}
	public String getSjoindate() {
		return sjoindate;
	}
	public void setSjoindate(String sjoindate) {
		this.sjoindate = sjoindate;
	}
	public String getSmobilephone() {
		return smobilephone;
	}
	public void setSmobilephone(String smobilephone) {
		this.smobilephone = smobilephone;
	}
	public String getSofficephone() {
		return sofficephone;
	}
	public void setSofficephone(String sofficephone) {
		this.sofficephone = sofficephone;
	}
	
	
}
