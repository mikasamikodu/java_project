package com.entity;

public class HeadManage {
	private String systemName;//�ⲿϵͳ����
	private String billDefine;//ʵ���ʲ��̶��ֶ�
	private String userId;//�û�id
	private String operaterType;//��Ϣ������ʾ
	private String dataId;//����Ψһ��ʶ
	
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getBillDefine() {
		return billDefine;
	}
	public void setBillDefine(String billDefine) {
		this.billDefine = billDefine;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOperaterType() {
		return operaterType;
	}
	public void setOperaterType(String operaterType) {
		this.operaterType = operaterType;
	}
	public String getDataId() {
		return dataId;
	}
	public void setDataId(String dataId) {
		this.dataId = dataId;
	}
	
}
