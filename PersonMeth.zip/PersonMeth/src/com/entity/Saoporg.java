package com.entity;

public class Saoporg {
	private String sid;//
	private String organizationID;//�������
	private String organization;//��������
	private String departmentID;//���ű��
	private String department;//��������
	private String sorgKindId;//
	private String sfid;
	private String sfcode;
	private String spersonid;
	private String ssequence;
	private String companyid;
	
	public String getCompanyid() {
		return companyid;
	}
	public void setCompanyid(String companyid) {
		this.companyid = companyid;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	private String company;
	
	
	public String getSsequence() {
		return ssequence;
	}
	public void setSsequence(String ssequence) {
		this.ssequence = ssequence;
	}
	public String getSpersonid() {
		return spersonid;
	}
	public void setSpersonid(String spersonid) {
		this.spersonid = spersonid;
	}
	public String getSfcode() {
		return sfcode;
	}
	public void setSfcode(String sfcode) {
		this.sfcode = sfcode;
	}
	private Integer version;
	
	public String getSfid() {
		return sfid;
	}
	public void setSfid(String sfid) {
		this.sfid = sfid;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getOrganizationID() {
		return organizationID;
	}
	public void setOrganizationID(String organizationID) {
		this.organizationID = organizationID;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getDepartmentID() {
		return departmentID;
	}
	public void setDepartmentID(String departmentID) {
		this.departmentID = departmentID;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getSorgKindId() {
		return sorgKindId;
	}
	public void setSorgKindId(String sorgKindId) {
		this.sorgKindId = sorgKindId;
	}
	
	
}
