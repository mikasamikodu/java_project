package com.service;

public interface EmpDeptService {
	String importName(String requestXml);
}
