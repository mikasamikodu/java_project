package com.service;

public interface ImportVendorService {
	String importVendorInfo(String requestXml);
}
