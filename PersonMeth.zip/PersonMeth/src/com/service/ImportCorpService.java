package com.service;

public interface ImportCorpService {
	String importCorpInfo(String requestXml);
}
