package com.dao;

import java.util.List;

public interface ImportCorpDao {
	String importCorpInfo(List<Object> obj);
}
