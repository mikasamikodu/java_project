package com.dao;

import java.util.List;

public interface ImportVendorDao {
	String importVendorInfo(List<Object> objlist);
}
