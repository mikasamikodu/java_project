package com.text;

import com.importInfo.impl.ImportNameImpl;

public class Test3 {
	public static void main(String[] args) {
		ImportNameImpl i=new ImportNameImpl();
		i.importNameInfo();
	}
}
