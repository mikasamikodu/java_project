package com.importInfo;

public interface ImportName {
	public void importNameInfo();
	
}
