package com.importInfo;

public interface ImportOgnDpt {
	public void importOgnDptInfo();
}
